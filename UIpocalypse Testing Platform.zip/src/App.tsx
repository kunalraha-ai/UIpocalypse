import { useEffect, useMemo, useState, type ReactNode } from 'react'

type IconName =
  | 'arrow' | 'bolt' | 'bot' | 'check' | 'code' | 'copy' | 'eye' | 'file'
  | 'graph' | 'grid' | 'lock' | 'menu' | 'moon' | 'play' | 'plus' | 'report'
  | 'search' | 'settings' | 'shield' | 'spark' | 'stop' | 'sun' | 'terminal'
  | 'user' | 'warning' | 'x'

const iconPaths: Record<IconName, ReactNode> = {
  arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
  bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7z"/>,
  bot: <><rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M8 12h.01M16 12h.01M8 16h8"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  code: <><path d="m8 9-4 3 4 3M16 9l4 3-4 3M14 5l-4 14"/></>,
  copy: <><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></>,
  eye: <><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12"/><circle cx="12" cy="12" r="2.5"/></>,
  file: <><path d="M6 2h8l4 4v16H6z"/><path d="M14 2v5h5M9 13h6M9 17h4"/></>,
  graph: <><circle cx="5" cy="16" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="19" cy="14" r="2"/><path d="m6 14 5-6M14 7l4 5M7 16h10"/></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
  lock: <><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
  menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
  moon: <path d="M20 15.5A8 8 0 0 1 8.5 4 8 8 0 1 0 20 15.5z"/>,
  play: <path d="m8 5 11 7-11 7z"/>,
  plus: <path d="M12 5v14M5 12h14"/>,
  report: <><path d="M5 3h14v18H5z"/><path d="M9 8h6M9 12h6M9 16h3"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H3v-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.6V3h4v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1z"/></>,
  shield: <><path d="M12 2 4 5v6c0 5 3.5 9 8 11 4.5-2 8-6 8-11V5z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></>,
  spark: <path d="m12 2 1.5 6.5L20 10l-6.5 1.5L12 18l-1.5-6.5L4 10l6.5-1.5z"/>,
  stop: <rect x="6" y="6" width="12" height="12" rx="1"/>,
  sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></>,
  terminal: <><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M13 15h4"/></>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c.5-4 3-6 8-6s7.5 2 8 6"/></>,
  warning: <><path d="M12 3 2 21h20z"/><path d="M12 9v5M12 18h.01"/></>,
  x: <path d="m6 6 12 12M18 6 6 18"/>,
}

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{iconPaths[name]}</svg>
}

const route = () => window.location.hash.slice(1) || '/'
function navigate(to: string) { window.location.hash = to }

function Button({ children, to, variant = 'primary', icon, type = 'button', disabled, onClick }: {
  children: ReactNode; to?: string; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; icon?: IconName;
  type?: 'button' | 'submit'; disabled?: boolean; onClick?: () => void
}) {
  const cls = `btn btn-${variant}`
  if (to) return <a className={cls} href={`#${to}`}>{children}{icon && <Icon name={icon}/>}</a>
  return <button className={cls} type={type} disabled={disabled} onClick={onClick}>{children}{icon && <Icon name={icon}/>}</button>
}

function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral'|'critical'|'high'|'medium'|'good'|'blue' }) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}

function Card({ children, className = '', interactive = false }: { children: ReactNode; className?: string; interactive?: boolean }) {
  return <div className={`card ${interactive ? 'card-interactive' : ''} ${className}`}>{children}</div>
}

function Logo({ compact = false }: { compact?: boolean }) {
  return <a href="#/" className="logo" aria-label="UIpocalypse home">
    <span className="logo-mark"><span/><span/><span/></span>
    {!compact && <span>UI<span>pocalypse</span></span>}
  </a>
}

function ThemeToggle({ theme, setTheme }: { theme: string; setTheme: (x: string) => void }) {
  return <button className="icon-btn" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}>
    <Icon name={theme === 'dark' ? 'sun' : 'moon'}/>
  </button>
}

const nav = [
  ['How it works', '/how-it-works'], ['Features', '/features'], ['Personas', '/personas'],
  ['Safety', '/safety'], ['Docs', '/docs'], ['Pricing', '/pricing'],
]

function MarketingHeader({ theme, setTheme }: { theme: string; setTheme: (x: string) => void }) {
  const [open, setOpen] = useState(false)
  return <header className="site-header">
    <div className="nav-wrap">
      <Logo/>
      <nav className={`main-nav ${open ? 'open' : ''}`} aria-label="Main navigation">
        {nav.map(([label, to]) => <a key={to} href={`#${to}`} onClick={() => setOpen(false)}>{label}</a>)}
      </nav>
      <div className="nav-actions">
        <ThemeToggle theme={theme} setTheme={setTheme}/>
        <Button to="/app/projects" variant="ghost">App preview</Button>
        <Button to="/early-access">Get early access</Button>
        <button className="icon-btn mobile-menu" aria-label="Toggle menu" onClick={() => setOpen(!open)}><Icon name={open ? 'x' : 'menu'}/></button>
      </div>
    </div>
  </header>
}

function Footer() {
  return <footer className="footer">
    <div className="footer-grid">
      <div><Logo/><p>Break it here, not in production.</p><Badge tone="blue">Private beta</Badge></div>
      <div><strong>Product</strong><a href="#/features">Features</a><a href="#/personas">Personas</a><a href="#/safety">Safety</a><a href="#/benchmarks">Benchmarks</a></div>
      <div><strong>Learn</strong><a href="#/docs">Documentation</a><a href="#/blog">Changelog</a><a href="#/about">About & contact</a><a href="#/badge">Badge</a></div>
      <div><strong>Legal</strong><a href="#/terms">Terms</a><a href="#/privacy">Privacy</a><a href="#/404">404 page</a></div>
    </div>
    <div className="footer-bottom"><span>© 2025 UIpocalypse. Preview content.</span><span>Designed for test copies, never production.</span></div>
  </footer>
}

function MarketingShell({ children, theme, setTheme }: { children: ReactNode; theme: string; setTheme: (x: string) => void }) {
  return <><MarketingHeader theme={theme} setTheme={setTheme}/><main>{children}</main><Footer/></>
}

function Eyebrow({ children }: { children: ReactNode }) { return <div className="eyebrow"><span/> {children}</div> }
function SectionTitle({ eyebrow, title, copy, center = false }: { eyebrow?: string; title: string; copy?: string; center?: boolean }) {
  return <div className={`section-title ${center ? 'center' : ''}`}>
    {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}<h2>{title}</h2>{copy && <p>{copy}</p>}
  </div>
}

function BotVisual() {
  return <div className="hero-visual" aria-label="Illustration of bot agents testing an application">
    <div className="scan-line"/>
    <div className="visual-top"><span><i/> localhost:3000 / checkout</span><Badge tone="good">TEST COPY</Badge></div>
    <div className="mock-app">
      <div className="mock-sidebar"><b/><i/><i/><i/><i/></div>
      <div className="mock-content">
        <div className="mock-heading"/><div className="mock-copy"/>
        <div className="mock-cards"><span/><span/><span/></div>
        <div className="mock-form"><i/><i/><b/></div>
      </div>
      {[
        ['bot-a','W','Clicking everything'], ['bot-b','D','Double submit'], ['bot-c','R','Racing request']
      ].map(([c,l,t]) => <div className={`bot-chip ${c}`} key={c}><span>{l}</span>{t}</div>)}
      <div className="cursor cursor-a">↖</div><div className="cursor cursor-b">↖</div><div className="cursor cursor-c">↖</div>
    </div>
    <div className="visual-report">
      <div><span className="status-dot"/><strong>Finding clustered</strong><small>High confidence</small></div>
      <p>Double-submit on <code>POST /api/credits/buy</code> creates duplicate rows</p>
      <span className="sample-label">SAMPLE DATA</span>
    </div>
  </div>
}

const features = [
  ['code','Static code scan','Find dead handlers, risky writes, missing guards, and testable actions before the browser opens.'],
  ['bot','Chaos personas','Purpose-built agents wander, double-click, paste garbage, abandon flows, and race each other.'],
  ['bolt','Race detection','Coordinate simultaneous actions to expose duplicate writes and single-use resources used twice.'],
  ['graph','State coverage','See which states, routes, and actions were reached, skipped, blocked, or remain unknown.'],
  ['spark','Fix prompts','Copy evidence-rich prompts into Cursor, Claude Code, or the AI coding tool you already use.'],
] as const

function Landing() {
  const [faq, setFaq] = useState(0)
  return <>
    <section className="hero page-width">
      <div className="hero-copy">
        <Eyebrow>Local-first chaos testing for AI-built apps</Eyebrow>
        <h1>An apocalypse for your UI. <em>For the better.</em></h1>
        <p>Launch an army of chaotic bot users into a real browser, catch what actually breaks, and take fix-ready evidence back to your coding agent.</p>
        <div className="button-row"><Button to="/early-access" icon="arrow">Get early access</Button><Button to="/how-it-works" variant="secondary" icon="play">See how it works</Button></div>
        <div className="trust-row"><span><Icon name="lock"/> Runs locally</span><span><Icon name="shield"/> Test copies only</span><span><Icon name="code"/> Code stays yours</span></div>
      </div>
      <BotVisual/>
    </section>

    <section className="signal-strip">
      <div className="page-width"><span>BUILT FOR</span><b>Lovable</b><i>×</i><b>Bolt</b><i>×</i><b>Cursor</b><i>×</i><b>Claude Code</b><i>×</i><b>and your terminal</b></div>
    </section>

    <section className="section page-width">
      <SectionTitle eyebrow="The pipeline" title="From codebase to bug trail in four steps." copy="UIpocalypse reads what could happen, then sends specialized agents to find out what actually breaks."/>
      <div className="steps-grid">
        {[
          ['01','Scan the code','Map routes, actions, forms, mutations, and safety risks.'],
          ['02','Plan the swarm','Choose personas and paths with the best chance of finding breakage.'],
          ['03','Release the bots','Run real browser sessions against your local test copy.'],
          ['04','Get the report','Review clustered findings, evidence, coverage, and fix prompts.'],
        ].map(([n,t,d]) => <Card key={n}><span className="step-no">{n}</span><h3>{t}</h3><p>{d}</p></Card>)}
      </div>
    </section>

    <section className="section section-tint">
      <div className="page-width">
        <SectionTitle eyebrow="Purpose-built pressure" title="Not another happy-path test runner." copy="The swarm behaves like users who are fast, impatient, confused, and unfortunately very real."/>
        <div className="feature-bento">
          {features.map(([icon,title,copy],i) => <Card key={title} className={i === 1 ? 'wide-card' : ''}>
            <span className="feature-icon"><Icon name={icon}/></span><h3>{title}</h3><p>{copy}</p>
            {i === 1 && <div className="mini-personas"><span>WANDERER</span><span>DOUBLE-CLICKER</span><span>RACE RUNNER</span></div>}
          </Card>)}
        </div>
      </div>
    </section>

    <section className="section page-width split-section">
      <div>
        <SectionTitle eyebrow="Inside your coding agent" title="One prompt in. Fix prompts out." copy="Run UIpocalypse through MCP without leaving the tool where you built your app."/>
        <ul className="check-list"><li><Icon name="check"/> Point it at a local test copy</li><li><Icon name="check"/> Review the safety plan before launch</li><li><Icon name="check"/> Paste verified evidence into your next fix</li></ul>
        <Button to="/docs/mcp" variant="secondary" icon="arrow">Configure MCP</Button>
      </div>
      <CodeBlock code={`You: Test my checkout flow safely.\n\nAgent: I found the test target at localhost:3000.\nI will skip payments, deletes, and external links.\nStart a 5-agent local run?\n\n> Yes, launch the swarm.`}/>
    </section>

    <section className="section safety-band">
      <div className="page-width safety-grid">
        <div><Eyebrow>Safety is the first phase</Eyebrow><h2>Chaos, with a very short leash.</h2><p>Every run happens locally against a test copy. Destructive actions, external hosts, payments, and irreversible operations are skipped by default.</p><Button to="/safety" variant="secondary" icon="arrow">Read the safety model</Button></div>
        <div className="guard-card">
          <div className="guard-ring"><Icon name="shield" size={34}/></div>
          <div><span><Icon name="check"/> localhost allowed</span><span><Icon name="check"/> production blocked</span><span><Icon name="check"/> secrets redacted</span><span><Icon name="check"/> destructive actions skipped</span></div>
        </div>
      </div>
    </section>

    <section className="section page-width">
      <SectionTitle eyebrow="Clear boundaries" title="It finds breakage. It does not grade taste." center/>
      <div className="compare-grid">
        <Card><Badge tone="good">WHAT IT FINDS</Badge><ul><li>Dead buttons and unhandled errors</li><li>Duplicate writes and race conditions</li><li>Broken navigation and failed requests</li><li>Launch-safety holes visible in code</li><li>Actions the swarm could not reach</li></ul></Card>
        <Card><Badge tone="neutral">WHAT IT DOES NOT</Badge><ul className="muted-list"><li>Judge whether your design looks good</li><li>Decide if a flow feels confusing</li><li>Prove your app has no bugs</li><li>Replace security review or human QA</li><li>Run against your production app</li></ul></Card>
      </div>
    </section>

    <section className="section section-tint">
      <div className="page-width faq-wrap">
        <SectionTitle eyebrow="FAQ" title="Before you release the swarm."/>
        <div className="faq-list">{[
          ['Does UIpocalypse test production?','No. It is designed to run locally against a disposable test copy of your app. Production targets are blocked by default.'],
          ['Does my code leave my machine?','Your code and secrets stay local. If you configure an LLM key, only redacted summaries are sent to that provider. No-LLM mode is available.'],
          ['Can it tell me if my UX is confusing?','No. UIpocalypse reports things that break. It does not make subjective design or usability judgments.'],
          ['Is the hosted dashboard available?','Not yet. The dashboard shown here is a future product concept. Join the beta for the local tool and product updates.'],
        ].map(([q,a],i) => <div className={`faq-item ${faq === i ? 'active' : ''}`} key={q}><button onClick={() => setFaq(faq === i ? -1 : i)} aria-expanded={faq === i}>{q}<Icon name={faq === i ? 'x' : 'plus'}/></button>{faq === i && <p>{a}</p>}</div>)}</div>
      </div>
    </section>
    <FinalCTA/>
  </>
}

function FinalCTA() {
  return <section className="final-cta page-width"><div><Eyebrow>Private beta</Eyebrow><h2>Find the breakage before your users do.</h2><p>Bring a test copy. We’ll bring the chaos.</p></div><Button to="/early-access" icon="arrow">Get early access</Button></section>
}

function PageHero({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) {
  return <section className="sub-hero page-width"><Eyebrow>{eyebrow}</Eyebrow><h1>{title}</h1><p>{copy}</p></section>
}

function HowItWorks() {
  const nodes = ['Code analyzer','Planner','Scouts','Swarm','Collector','Reviewer']
  return <>
    <PageHero eyebrow="Under the hood" title="A deliberate pipeline for controlled chaos." copy="UIpocalypse combines static analysis with coordinated browser agents, then turns noisy traces into a reviewable bug trail."/>
    <section className="section page-width">
      <div className="architecture">
        {nodes.map((n,i) => <div key={n} className="arch-node"><span><Icon name={i < 2 ? 'code' : i < 4 ? 'bot' : 'report'}/></span><b>{n}</b>{i < nodes.length-1 && <i><Icon name="arrow"/></i>}</div>)}
      </div>
      <div className="walkthrough">
        {[
          ['Inventory','The analyzer builds a local map of routes, controls, mutations, guards, and potential hazards.'],
          ['Plan','The planner proposes high-value paths and a safety envelope. You review skipped actions before launch.'],
          ['Scout','Low-cost scouts confirm what is reachable and record the initial state graph.'],
          ['Swarm','Specialized personas branch out, coordinate concurrency, and collect browser-level evidence.'],
          ['Collect','Related failures are clustered across agents so one root cause does not become twenty alerts.'],
          ['Review','The reviewer links evidence to likely files and produces a fix prompt—not an automatic code change.'],
        ].map(([t,d],i) => <div className="walk-row" key={t}><span>0{i+1}</span><div><h3>{t}</h3><p>{d}</p></div><Badge tone={i===3?'high':'neutral'}>{i===3?'LIVE BROWSERS':'LOCAL'}</Badge></div>)}
      </div>
    </section>
    <section className="section section-tint"><div className="page-width"><SectionTitle eyebrow="A sample run" title="Every phase explains itself."/><div className="timeline">{['Scan 0:00','Plan 0:18','Scout 0:31','Swarm 1:04','Report 4:20'].map((x,i)=><div key={x} className={i===3?'active':''}><span/><b>{x.split(' ')[0]}</b><small>{x.split(' ')[1]}</small></div>)}</div><Callout tone="info" title="Timing shown is sample data">Actual runtime depends on your app, hardware, agent count, and time budget.</Callout></div></section>
    <FinalCTA/>
  </>
}

function FeaturesPage() {
  return <>
    <PageHero eyebrow="Capabilities" title="Many ways to break. One report to fix from." copy="Static clues guide real browser exploration, while evidence and coverage keep every finding grounded."/>
    <section className="section page-width feature-list">
      {[
        ['code','Static rules','Surface dead event handlers, unsafe mutations, missing error boundaries, unguarded routes, and actions worth testing.','src/actions/credits.ts : 48'],
        ['bot','Chaos personas','Mix impatient, unpredictable, and concurrent behavior without pretending it is subjective UX review.','5 purpose-built behaviors'],
        ['bolt','Concurrency testing','Synchronize clicks and requests to probe idempotency, locking, coupon redemption, and duplicate writes.','20 concurrent redeems [sample]'],
        ['graph','State graph & coverage','Track visited states and exercised actions with explicit denominators—and explain every skip.','18 / 27 reachable actions [sample]'],
        ['report','Reports & diffs','Cluster findings, compare runs, and separate new, fixed, persistent, and intermittent failures.','3 new · 2 fixed [sample]'],
        ['spark','Fix prompts','Package reproduction steps, traces, code locations, and constraints for your AI coding tool.','Evidence included, fix not auto-applied'],
      ].map(([icon,title,copy,detail],i) => <div className="feature-row" key={title}><div className="feature-number">0{i+1}</div><span className="feature-icon"><Icon name={icon as IconName}/></span><div><h2>{title}</h2><p>{copy}</p></div><code>{detail}</code></div>)}
    </section><FinalCTA/>
  </>
}

const personas = [
  ['W','Wanderer','Takes plausible but unplanned paths, revisits screens, and clicks secondary actions.','Dead ends · broken navigation · stale state'],
  ['D','Double-Clicker','Clicks primary actions twice and retries before the UI can settle.','Duplicate writes · repeated charges · bad loading guards'],
  ['G','Garbage Paster','Pastes empty, huge, malformed, and surprising strings into form fields.','Unhandled errors · validation gaps · layout-breaking payloads'],
  ['A','Abandoner','Leaves multi-step flows halfway through, returns later, and resumes from odd states.','Orphaned drafts · expired state · broken resume flows'],
  ['R','Race Runner','Coordinates the same action across agents at nearly the same time.','Race conditions · single-use resource reuse · stale checks'],
]
function Personas() {
  return <><PageHero eyebrow="Meet the chaos crew" title="Built to behave badly. On purpose." copy="Each persona applies a narrow behavioral pressure. Combine them to match the failure modes you care about."/>
    <section className="section page-width persona-grid">{personas.map(([l,n,d,f],i)=><Card key={n} interactive><div className={`persona-art p${i}`}><span>{l}</span><i/><i/><b/></div><Badge tone="neutral">PERSONA 0{i+1}</Badge><h2>{n}</h2><p>{d}</p><div className="finds"><small>LIKELY TO FIND</small>{f}</div></Card>)}</section><FinalCTA/></>
}

function Safety() {
  return <><PageHero eyebrow="Safety & trust" title="Your test copy is the blast chamber." copy="The tool runs on your machine, against an environment you can throw away. Guardrails are visible before every run."/>
    <section className="section page-width">
      <div className="flow-diagram"><Card><Icon name="code" size={28}/><b>Your codebase</b><small>STAYS LOCAL</small></Card><Icon name="arrow"/><Card><Icon name="bot" size={28}/><b>Local runner</b><small>BROWSER + ANALYZER</small></Card><Icon name="arrow"/><Card><Icon name="report" size={28}/><b>Local report</b><small>EVIDENCE + FIX PROMPTS</small></Card></div>
      <div className="two-col-content">
        <div><h2>What leaves your machine?</h2><p>Nothing by default. In no-LLM mode, all analysis and browser control remain local.</p><p>If you explicitly set an LLM provider key, UIpocalypse can send redacted summaries to that provider. Source files, secrets, cookies, and raw environment variables are excluded.</p></div>
        <Callout tone="safe" title="Your key, your choice">LLM use is optional, clearly marked, and can be disabled per run. Provider handling is governed by the provider you choose.</Callout>
      </div>
    </section>
    <section className="section section-tint"><div className="page-width"><SectionTitle eyebrow="Default guard rules" title="Skipped unless you explicitly opt in."/><div className="rules-grid">{['Production-like hosts','Payments and purchases','Delete and bulk-delete actions','External domains','Emails, SMS, and webhooks','Database resets and migrations'].map(x=><Card key={x}><span className="rule-x"><Icon name="x"/></span><b>{x}</b><small>BLOCKED BY DEFAULT</small></Card>)}</div></div></section>
    <section className="section page-width"><SectionTitle title="Before launch, the plan is yours to approve."/><div className="safety-check"><div><Icon name="check"/><span><b>Target ownership confirmed</b><small>localhost:3000 · test environment</small></span></div><div><Icon name="check"/><span><b>Skipped actions reviewed</b><small>12 actions · 4 external hosts</small></span></div><div><Icon name="check"/><span><b>Destructive actions off</b><small>Explicit opt-in required</small></span></div><Button variant="secondary">Review run plan</Button></div></section>
  </>
}

function Benchmarks() {
  return <><PageHero eyebrow="Proof template" title="Benchmarks, without the theater." copy="This page is ready for reproducible results once they exist. Until then, every value is clearly marked as sample data."/>
    <section className="section page-width"><Callout tone="warn" title="All values below are placeholders">Do not use this table to evaluate product performance. Replace only with results from a published, repeatable methodology.</Callout>
      <div className="table-wrap"><table><thead><tr><th>Fixture</th><th>Known breakages</th><th>Found</th><th>False positives</th><th>Runtime</th></tr></thead><tbody>{['Sample checkout app','Sample account app','Sample credits app'].map(x=><tr key={x}><td>{x}</td><td>[sample]</td><td>[sample]</td><td>[sample]</td><td>[sample]</td></tr>)}</tbody></table></div>
      <div className="two-col-content"><div><h2>Methodology</h2><ol><li>Publish fixture source and planted defects.</li><li>Pin UIpocalypse version, models, and machine specs.</li><li>Run the same configuration multiple times.</li><li>Report denominators, misses, and variance.</li></ol></div><Callout tone="neutral" title="What this does not show">A benchmark cannot prove safety, complete coverage, zero bugs, or performance on your app. It also does not measure design or usability quality.</Callout></div>
    </section></>
}

function Pricing() {
  return <><PageHero eyebrow="Pricing" title="Start local. Grow into a team." copy="The local beta is the product today. Hosted collaboration is a future direction, not a feature you can buy yet."/>
    <section className="section page-width pricing-grid">
      <Card className="price-card"><Badge tone="good">PRIVATE BETA</Badge><h2>Local</h2><div className="price">Free <small>during beta</small></div><p>For vibecoders and small teams testing local copies.</p><ul><li>Local static scan</li><li>Browser swarm runs</li><li>Safety guardrails</li><li>Local reports and fix prompts</li><li>No-LLM mode</li></ul><Button to="/early-access">Join the beta</Button></Card>
      <Card className="price-card coming"><Badge tone="blue">COMING LATER</Badge><h2>Hosted team</h2><div className="price">TBD <small>not for sale</small></div><p>Potential collaboration features for teams.</p><ul><li>Run history</li><li>CI workflows</li><li>Shared reports</li><li>Team verdicts</li><li>Project trends</li></ul><Button disabled variant="secondary">Not yet available</Button></Card>
    </section>
    <section className="section page-width"><SectionTitle title="Pricing FAQ"/><div className="compare-grid"><Card><h3>Will the local tool stay available?</h3><p>The current plan is to offer a useful local tier. Final packaging may change as the beta teaches us what teams need.</p></Card><Card><h3>Can I buy the hosted version?</h3><p>No. The hosted dashboard is a product concept and the team tier is labeled “coming later” intentionally.</p></Card></div></section><FinalCTA/></>
}

function EarlyAccess() {
  const [sent,setSent]=useState(false)
  if(sent) return <section className="form-page page-width"><div className="confirmation"><span><Icon name="check" size={34}/></span><Eyebrow>Request received</Eyebrow><h1>You’re on the beta list.</h1><p>Thanks for volunteering your app as a controlled blast zone. We’ll follow up at the email you provided.</p><Button to="/">Back to home</Button></div></section>
  return <section className="form-page page-width">
    <div><Eyebrow>Private beta</Eyebrow><h1>Bring a test copy.<br/>We’ll bring the chaos.</h1><p>Tell us what you build with. Early access is reviewed in batches so we can support each setup properly.</p><div className="trust-stack"><span><Icon name="lock"/> No production targets</span><span><Icon name="code"/> Code and secrets stay local</span><span><Icon name="user"/> No spam or sold data</span></div></div>
    <form className="signup-form" onSubmit={e=>{e.preventDefault();setSent(true)}}>
      <h2>Request access</h2><Field label="Name" placeholder="Ada Lovelace"/><Field label="Work email" placeholder="ada@example.com" type="email"/>
      <label className="field"><span>Primary stack</span><select required defaultValue=""><option value="" disabled>Select a stack</option><option>React / Next.js</option><option>React / Vite</option><option>Vue / Nuxt</option><option>Other</option></select></label>
      <div className="field-pair"><Field label="Operating system" placeholder="macOS"/><Field label="How many apps?" placeholder="2"/></div>
      <fieldset><legend>Can you make a disposable test copy?</legend><label><input type="radio" name="copy" required/> Yes, locally</label><label><input type="radio" name="copy"/> I need help</label></fieldset>
      <label className="checkbox"><input type="checkbox" required/><span>I agree to receive beta updates and accept the <a href="#/privacy">privacy policy</a>.</span></label>
      <Button type="submit" icon="arrow">Request early access</Button>
    </form>
  </section>
}

function Field({label,placeholder,type='text'}:{label:string;placeholder:string;type?:string}) {
  return <label className="field"><span>{label}</span><input type={type} placeholder={placeholder} required/></label>
}

function CodeBlock({code}:{code:string}) {
  const [copied,setCopied]=useState(false)
  return <div className="code-block"><div><span/><span/><span/><small>terminal</small><button onClick={()=>{navigator.clipboard?.writeText(code);setCopied(true);setTimeout(()=>setCopied(false),1200)}}><Icon name="copy"/>{copied?'Copied':'Copy'}</button></div><pre>{code}</pre></div>
}

function Callout({tone,title,children}:{tone:'info'|'warn'|'safe'|'neutral';title:string;children:ReactNode}) {
  return <div className={`callout callout-${tone}`}><Icon name={tone==='warn'?'warning':tone==='safe'?'shield':'spark'}/><div><b>{title}</b><p>{children}</p></div></div>
}

const docNav = ['Quickstart','Make a safe test copy','What leaves your machine','MCP configuration','Scope and limits','FAQ']
function Docs({article='Quickstart'}:{article?:string}) {
  const slug=(x:string)=>x.toLowerCase().replaceAll(' ','-')
  return <div className="docs-layout page-width">
    <aside className="docs-side"><a href="#/docs" className="docs-title"><Icon name="file"/> Documentation</a><label className="search-box"><Icon name="search"/><input aria-label="Search docs" placeholder="Search docs…"/><kbd>⌘K</kbd></label><nav>{docNav.map(x=><a className={x===article?'active':''} href={`#/docs/${slug(x)}`} key={x}>{x}</a>)}</nav><Callout tone="safe" title="Local by design">Your app code stays on your machine.</Callout></aside>
    <article className="doc-article"><div className="breadcrumbs">DOCS / GETTING STARTED</div><h1>{article}</h1>
      {article==='Quickstart' ? <><p className="lede">Install UIpocalypse, prepare a disposable test copy, and launch a guarded first swarm.</p><Callout tone="warn" title="Do not point this at production">Use a local test copy with disposable data. UIpocalypse intentionally stresses actions and state.</Callout><h2>1. Install the local runner</h2><CodeBlock code="npx uipocalypse@beta init"/><h2>2. Start a disposable copy</h2><p>Use a separate database and test credentials. Confirm that payment, email, webhook, and deletion actions are disabled.</p><CodeBlock code={`# Example only\nTEST_MODE=true\nDATABASE_URL=postgres://localhost/myapp_chaos\nnpm run dev`}/><h2>3. Review, then run</h2><CodeBlock code="uipocalypse run http://localhost:3000 --review-plan"/><Callout tone="info" title="Next step">The runner will show the planned hosts, skipped actions, personas, and time budget before any bot opens a browser.</Callout></> :
      <DocArticleContent title={article}/>}
    </article>
    <aside className="on-page"><b>ON THIS PAGE</b><a href="#">Overview</a><a href="#">Configuration</a><a href="#">Guardrails</a><a href="#">Next steps</a></aside>
  </div>
}

function DocArticleContent({title}:{title:string}) {
  const copy:Record<string,[string,string]> = {
    'Make a safe test copy':['Clone the environment, not the risk.','Use disposable data, test-only credentials, and disable every integration that can affect a real person or account.'],
    'What leaves your machine':['Local first means local by default.','Code, secrets, browser storage, and raw traces remain local. Redacted summaries leave only when you configure an LLM key.'],
    'MCP configuration':['Run the swarm from your coding agent.','Connect the local MCP server, then ask your agent to prepare a reviewed run against a test target.'],
    'Scope and limits':['What the tool can—and cannot—tell you.','UIpocalypse finds observable breakage. It does not judge design quality, certify security, or prove the absence of bugs.'],
    'FAQ':['Answers without fine-print acrobatics.','Common questions about local execution, test targets, LLM use, reports, and beta access.'],
  }
  const [h,p]=copy[title]||['Documentation article','Practical guidance for safe chaos testing.']
  return <><p className="lede">{h}</p><p>{p}</p><h2>Overview</h2><p>Start with the narrowest possible target and a disposable data set. Review the run plan, then expand scope only after the first report is understood.</p><Callout tone="safe" title="Recommended default">Keep destructive actions and external hosts disabled. Prefer no-LLM mode when evaluating sensitive projects.</Callout><h2>Configuration</h2><CodeBlock code={`{\n  "target": "http://localhost:3000",\n  "destructiveActions": false,\n  "externalHosts": [],\n  "llm": "off"\n}`}/><h2>Limits</h2><p>A clean run means only that the configured agents did not observe breakage in the paths they reached during that run.</p></>
}

function Blog() {
  return <><PageHero eyebrow="Field notes" title="Changelog & dispatches." copy="Product updates, technical notes, and lessons from teaching bots to behave badly."/><section className="section page-width blog-grid">{[
    ['CHANGELOG','Beta runner 0.4: safer plans, clearer skips','The run plan now groups guarded actions by reason and makes external hosts easier to audit.','[sample date]'],
    ['ENGINEERING','Why twenty alerts might be one bug','How clustering turns repeated browser failures into a reviewable root-cause trail.','[sample date]'],
    ['GUIDE','A disposable test copy is part of the test','Practical boundaries for databases, webhooks, email, payments, and third-party services.','[sample date]'],
  ].map(([tag,t,d,date],i)=><a className="blog-card" href="#/blog/article" key={t}><div className={`blog-art art-${i}`}><Icon name={i===0?'bolt':i===1?'graph':'shield'} size={40}/></div><Badge tone="neutral">{tag}</Badge><h2>{t}</h2><p>{d}</p><small>{date} · [sample] min read</small></a>)}</section></>
}

function BlogArticle() {
  return <article className="article-page page-width"><div className="breadcrumbs">CHANGELOG / [SAMPLE DATE]</div><h1>Beta runner 0.4: safer plans, clearer skips</h1><p className="lede">This sample article layout shows how product updates explain both what changed and what remains limited.</p><div className="article-meta"><Badge tone="blue">CHANGELOG</Badge><span>UIpocalypse team</span><span>[sample] min read</span></div><div className="article-cover"><Icon name="bolt" size={64}/></div><h2>The run plan is now easier to audit</h2><p>Before browsers launch, actions are grouped by the guard that affects them. This makes it easier to see why a payment route, external host, or destructive control will not run.</p><blockquote>Skipped actions are coverage information—not missing data to hide.</blockquote><h2>What this does not change</h2><p>UIpocalypse still requires a disposable test copy and still blocks production-like targets by default. The tool finds observable breakage; it does not certify that your app is safe or bug-free.</p></article>
}

function About() {
  return <><PageHero eyebrow="About UIpocalypse" title="We want AI-built apps to survive contact with reality." copy="UIpocalypse is being built for the people shipping useful software faster than traditional test practices can keep up."/><section className="section page-width two-col-content"><div><h2>Why this exists</h2><p>AI tools can help small teams produce a surprising amount of software. But every generated button, mutation, and flow expands the surface that can break.</p><p>Our premise is simple: read the code for clues, behave worse than the happy path, and return evidence a coding agent can act on.</p></div><Card><Eyebrow>Contact</Eyebrow><h2>Have a strange app to test?</h2><p>We especially want to hear from teams with multi-step flows, credits, coupons, queues, or collaborative state.</p><Button to="/early-access">Talk to us</Button></Card></section></>
}

function Legal({type}:{type:'Terms'|'Privacy'}) {
  return <article className="legal page-width"><Eyebrow>Legal template</Eyebrow><h1>{type}</h1><p className="lede">Last updated: [placeholder date]</p><Callout tone="warn" title="Template content">This page is a designed placeholder and requires review by qualified legal counsel before publication.</Callout>{['Overview','Using the local tool',type==='Privacy'?'Data handling':'Acceptable use','Third-party providers','Limitations','Contact'].map(x=><section key={x}><h2>{x}</h2><p>[Placeholder legal copy.] This section will explain the applicable terms in clear language, including local processing, optional providers, test-only targets, responsibilities, retention, and user choices.</p></section>)}</article>
}

function NotFound({error=false}:{error?:boolean}) {
  return <section className="not-found page-width"><div className="glitch">{error?'500':'404'}<span>{error?'500':'404'}</span></div><Eyebrow>{error?'Something broke':'This route wandered off'}</Eyebrow><h1>{error?'The swarm hit an unexpected wall.':'Even the Wanderer couldn’t find this page.'}</h1><p>{error?'Your data is safe. Try again, or return to the dashboard.':'Check the URL or head back before the bots make it worse.'}</p><div className="button-row"><Button to={error?'/app/projects':'/'}>Return {error?'to projects':'home'}</Button><Button to="/docs" variant="secondary">Open docs</Button></div></section>
}

// PRODUCT APP
const appNav = [
  ['grid','Projects','/app/projects'],['play','New run','/app/new-run'],['report','Reports','/app/report'],
  ['graph','State graph','/app/graph'],['code','Static scan','/app/static-scan'],['settings','Settings','/app/settings'],
] as const

function AppShell({children, theme, setTheme}:{children:ReactNode;theme:string;setTheme:(x:string)=>void}) {
  return <div className="app-shell"><aside className="app-side"><Logo compact/><nav>{appNav.map(([i,l,to])=><a href={`#${to}`} className={route()===to?'active':''} key={to}><Icon name={i}/><span>{l}</span></a>)}</nav><div className="app-side-bottom"><a href="#/docs"><Icon name="file"/><span>Docs</span></a><ThemeToggle theme={theme} setTheme={setTheme}/><div className="avatar">AL</div></div></aside><div className="app-main"><header className="app-top"><div><Badge tone="blue">HOSTED PREVIEW</Badge><span>Dashboard concept · local beta is available now</span></div><Button to="/early-access" variant="secondary">Join beta</Button></header>{children}</div></div>
}

function AppPageHead({title,copy,actions}:{title:string;copy?:string;actions?:ReactNode}) {
  return <div className="app-page-head"><div><div className="breadcrumbs">ACME LAB / {title.toUpperCase()}</div><h1>{title}</h1>{copy&&<p>{copy}</p>}</div>{actions&&<div className="button-row">{actions}</div>}</div>
}

function Projects() {
  return <div className="app-page"><AppPageHead title="Projects" copy="Test copies connected to UIpocalypse." actions={<Button to="/app/onboarding" icon="plus">Connect project</Button>}/>
    <div className="metric-grid"><Metric label="Projects" value="3" note="sample data"/><Metric label="Open findings" value="12" note="sample data"/><Metric label="Runs this month" value="18" note="sample data"/></div>
    <div className="project-grid">{[
      ['Credit Kitchen','React + Vite','5 high','Run completed 2h ago'],['Tiny CRM','Next.js','2 medium','Run completed yesterday'],['Coupon Lab','Vue','Setup needed','No runs yet']
    ].map(([n,s,f,r],i)=><Card key={n} interactive><div className="project-top"><span className={`project-icon pi-${i}`}><Icon name="terminal"/></span><span className="more">•••</span></div><h2>{n}</h2><p>{s} · localhost:{3000+i}</p><div className="project-meta"><Badge tone={i===0?'high':i===1?'medium':'neutral'}>{f}</Badge><small>{r}</small></div><div className="sparkline"><svg viewBox="0 0 240 50"><polyline points={i===0?'0,12 35,18 70,15 105,30 140,24 175,40 210,34 240,42':'0,40 35,34 70,38 105,25 140,30 175,18 210,20 240,12'}/></svg></div><Button to="/app/project" variant="secondary">Open project</Button></Card>)}</div>
  </div>
}

function Metric({label,value,note}:{label:string;value:string;note?:string}) {return <Card className="metric"><small>{label}</small><strong>{value}</strong>{note&&<span>{note}</span>}</Card>}

function ProjectOverview() {
  return <div className="app-page"><AppPageHead title="Credit Kitchen" copy="http://localhost:3000 · React + Vite" actions={<><Button to="/app/new-run" icon="play">Run again</Button><Button variant="secondary">Project settings</Button></>}/>
    <div className="metric-grid four"><Metric label="Latest run" value="Completed"/><Metric label="Open findings" value="5" note="sample"/><Metric label="Action coverage" value="18/27" note="sample"/><Metric label="Last tested" value="2h ago" note="sample"/></div>
    <div className="dash-grid"><Card className="run-summary"><div className="card-head"><div><Badge tone="good">COMPLETED</Badge><h2>Run #024</h2></div><small>4m 20s · [sample]</small></div><div className="finding-preview"><Badge tone="high">HIGH</Badge><div><b>Double-submit creates duplicate credit rows</b><small>POST /api/credits/buy · 4 agents reproduced</small></div><a href="#/app/finding"><Icon name="arrow"/></a></div><div className="finding-preview"><Badge tone="medium">MEDIUM</Badge><div><b>Dead button: Save profile</b><small>/settings/profile · 2 agents reproduced</small></div><a href="#/app/finding"><Icon name="arrow"/></a></div><Button to="/app/report" variant="secondary">View full report</Button></Card>
    <Card><div className="card-head"><h2>Open issues</h2><Badge tone="neutral">SAMPLE</Badge></div><div className="donut-wrap"><div className="donut"><span>12<small>total</small></span></div><div><span><i className="crit"/> Critical 1</span><span><i className="hi"/> High 4</span><span><i className="med"/> Medium 7</span></div></div></Card></div>
  </div>
}

function NewRun() {
  const [agents,setAgents]=useState(5); const [risky,setRisky]=useState(false); const [modal,setModal]=useState(false)
  return <div className="app-page narrow-app"><AppPageHead title="Configure new run" copy="Credit Kitchen · All settings are reviewed before launch."/>
    <div className="config-layout"><div className="config-main">
      <Card><h2>Target</h2><Field label="Test target URL" placeholder="http://localhost:3000"/><Callout tone="safe" title="Local test target recognized">Ownership check passed. This target resolves to your machine.</Callout></Card>
      <Card><h2>Run shape</h2><label className="range-label"><span>Browser agents <b>{agents}</b></span><input type="range" min="1" max="20" value={agents} onChange={e=>setAgents(+e.target.value)}/></label><label className="field"><span>Time budget</span><select><option>5 minutes</option><option>10 minutes</option><option>20 minutes</option></select></label></Card>
      <Card><h2>Personas</h2><div className="toggle-grid">{personas.map(([l,n])=><label className="toggle-row" key={n}><span className="mini-avatar">{l}</span><b>{n}</b><input type="checkbox" defaultChecked={n!=='Abandoner'}/><i/></label>)}</div></Card>
      <Card><div className="card-head"><h2>Skipped actions</h2><Badge tone="good">12 GUARDED</Badge></div><textarea aria-label="Skipped actions" defaultValue={"**/delete/**\n**/checkout/**\nmailto:* · external hosts"}/></Card>
      <Card className="danger-zone"><h2>Risk controls</h2><Toggle label="Allow destructive actions" warning="May delete or permanently change test data." value={risky} setValue={(v)=>v?setModal(true):setRisky(false)}/><Toggle label="Allow external actions" warning="May trigger webhooks, email, or third-party services."/>\n<Toggle label="LLM mode" warning="Sends redacted summaries to your configured provider." defaultOn/></Card>
    </div><aside className="run-estimate"><Card><h3>Run estimate</h3><div><span>Agents</span><b>{agents}</b></div><div><span>Max duration</span><b>5 min</b></div><div><span>LLM cost</span><b>[sample]</b></div><div><span>Risk level</span><Badge tone={risky?'critical':'good'}>{risky?'ELEVATED':'GUARDED'}</Badge></div><Button to="/app/live-run" icon="play">Review & launch</Button><small>Nothing runs until the safety plan is confirmed.</small></Card></aside></div>
    {modal&&<Modal title="Enable destructive actions?" onClose={()=>setModal(false)}><Callout tone="warn" title="This can permanently change test data">Only continue if this is a disposable test copy and you can restore its database.</Callout><label className="checkbox"><input type="checkbox"/><span>I understand this can delete test data.</span></label><div className="button-row"><Button variant="secondary" onClick={()=>setModal(false)}>Cancel</Button><Button variant="danger" onClick={()=>{setRisky(true);setModal(false)}}>Enable destructive actions</Button></div></Modal>}
  </div>
}

function Toggle({label,warning,value,setValue,defaultOn}:{label:string;warning:string;value?:boolean;setValue?:(x:boolean)=>void;defaultOn?:boolean}) {
  return <label className="risk-toggle"><div><b>{label}</b><small>{warning}</small></div><input type="checkbox" checked={value} onChange={e=>setValue?.(e.target.checked)} defaultChecked={value===undefined?defaultOn:undefined}/><i/></label>
}

function Modal({title,children,onClose}:{title:string;children:ReactNode;onClose:()=>void}) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.currentTarget===e.target)onClose()}}><div className="modal" role="dialog" aria-modal="true" aria-label={title}><div className="card-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose}><Icon name="x"/></button></div>{children}</div></div>
}

function LiveRun() {
  const phases=['Scan','Plan','Scout','Swarm','Report']
  return <div className="app-page"><AppPageHead title="Run #025 is live" copy="Credit Kitchen · Started [sample] ago" actions={<Button variant="danger" icon="stop">Stop run</Button>}/>
    <div className="phase-bar">{phases.map((p,i)=><div className={i<3?'done':i===3?'active':''} key={p}><span>{i<3?<Icon name="check"/>:i+1}</span><b>{p}</b><i/></div>)}</div>
    <div className="metric-grid four"><Metric label="Agents active" value="5/5"/><Metric label="Steps executed" value="147" note="sample"/><Metric label="Findings" value="4" note="sample"/><Metric label="Elapsed" value="03:12" note="sample"/></div>
    <div className="live-grid"><Card><div className="card-head"><h2>Agent swarm</h2><span className="live-dot">LIVE</span></div><div className="agent-grid">{personas.map(([l,n],i)=><div className="agent-tile" key={n}><span className={`agent-face p${i}`}>{l}</span><div><b>{n}</b><small>{i===1?'Clicking Buy credits':'Exploring /settings'}</small></div><span className="pulse"/></div>)}</div></Card>
    <Card><div className="card-head"><h2>Live findings</h2><Badge tone="neutral">SAMPLE</Badge></div><div className="feed">{['Dead button: Save profile','Unhandled error with a 10,000-character name','20 concurrent redeems: 2 succeeded','Duplicate POST created 2 rows'].map((x,i)=><div key={x}><span className={i>1?'feed-high':'feed-med'}><Icon name="warning"/></span><div><b>{x}</b><small>{i+1} agent{ i?'s':''} · just now</small></div></div>)}</div></Card></div>
  </div>
}

const findings=[
  ['critical','Double-submit creates duplicate credit rows','POST /api/credits/buy','4/5 agents'],
  ['high','20 concurrent redeems on single-use coupon: 2 succeeded','POST /api/coupons/redeem','2/5 agents'],
  ['medium','Unhandled error with a 10,000-character name','Profile form','1/5 agents'],
  ['medium','Dead button: Save profile','Settings','2/5 agents'],
]
function RunReport({shared=false}:{shared?:boolean}) {
  return <div className={shared?'shared-report page-width':'app-page'}>{shared&&<div className="shared-head"><Logo/><Badge tone="blue">SHARED REPORT · SAMPLE DATA</Badge></div>}<AppPageHead title="Run report #024" copy="Credit Kitchen · Completed [sample date] · 4m 20s" actions={!shared?<><Button to="/app/compare" variant="secondary">Compare run</Button><Button variant="secondary" icon="copy">Share</Button></>:undefined}/>
    <Callout tone="info" title="Run scope">Tested localhost:3000 with 5 browser agents. Payments, deletes, external links, and 12 guarded actions did not run.</Callout>
    <div className="report-summary"><Card><small>FINDINGS · SAMPLE</small><strong>5</strong><div className="severity-line"><i/><i/><i/><i/><i/></div></Card><Card><small>ACTION COVERAGE · SAMPLE</small><strong>18 / 27</strong><span>reachable actions exercised</span></Card><Card><small>STATE COVERAGE · SAMPLE</small><strong>14 / 21</strong><span>discovered states visited</span></Card><Card><small>MODELS USED</small><strong className="small-value">Local rules + [sample model]</strong><span>Machine: [sample specs]</span></Card></div>
    <div className="funnel"><div style={{width:'100%'}}>27 discovered actions</div><div style={{width:'82%'}}>22 safe to attempt</div><div style={{width:'67%'}}>18 exercised</div><div style={{width:'19%'}}>5 findings</div></div>
    <div className="report-list"><div className="card-head"><h2>Findings by cluster</h2><div><Badge tone="neutral">Severity ↓</Badge><Badge tone="good">High confidence</Badge></div></div>{findings.map(([sev,title,where,repro],i)=><a href="#/app/finding" className="finding-row" key={title}><Badge tone={sev as 'critical'|'high'|'medium'}>{sev.toUpperCase()}</Badge><div><b>{title}</b><small>{where}</small></div><div className="confidence"><span>CONFIDENCE</span><b>{i===2?'Medium':'High'}</b></div><div className="repro"><span>REPRODUCED</span><b>{repro}</b></div><Icon name="arrow"/></a>)}</div>
  </div>
}

function FindingDetail() {
  const [verdict,setVerdict]=useState('unsure'); const [toast,setToast]=useState(false)
  return <div className="app-page"><AppPageHead title="Double-submit creates duplicate credit rows" copy="Finding UIP-024-01 · POST /api/credits/buy" actions={<Button icon="copy" onClick={()=>{setToast(true);setTimeout(()=>setToast(false),1800)}}>Copy fix prompt</Button>}/>
    <div className="finding-badges"><Badge tone="critical">CRITICAL</Badge><Badge tone="good">HIGH CONFIDENCE</Badge><Badge tone="blue">RACE CONDITION</Badge><Badge tone="neutral">SAMPLE DATA</Badge></div>
    <div className="finding-layout"><div>
      <Card><h2>What broke</h2><p>Two rapid submissions passed the balance check before either write completed. Both requests returned 200 and created separate credit rows.</p><Callout tone="warn" title="Observed impact">One user action produced two successful writes. No real payment provider was called in this test.</Callout></Card>
      <Card><h2>Steps to reproduce</h2><ol className="repro-steps"><li><span>1</span>Open <code>/credits</code> with a test account.</li><li><span>2</span>Select the “100 credits” option.</li><li><span>3</span>Submit twice within 84ms <Badge tone="neutral">SAMPLE</Badge></li><li><span>4</span>Observe two 200 responses and two rows.</li></ol></Card>
      <Card><div className="card-head"><h2>Evidence</h2><Badge tone="neutral">2 REQUESTS</Badge></div><div className="evidence-tabs"><button className="active">Network</button><button>Console</button><button>Database diff</button></div><CodeBlock code={`POST /api/credits/buy  200  184ms\nPOST /api/credits/buy  200  191ms\n\n+ credit_purchase { id: "cp_8421", amount: 100 }\n+ credit_purchase { id: "cp_8422", amount: 100 }`}/></Card>
      <Card><h2>Replay</h2><div className="replay"><div><Icon name="play" size={28}/></div><span>00:03 / 00:11</span><input type="range" aria-label="Replay position"/></div></Card>
    </div><aside>
      <Card><small>AFFECTED CODE</small><h3>src/api/credits/buy.ts</h3><CodeBlock code={`48  const balance = await getBalance(user)\n49  if (balance >= cost) {\n50    await createPurchase(input)\n51  }`}/><a href="#/app/static-scan">Open in static scan <Icon name="arrow"/></a></Card>
      <Card><h3>Your verdict</h3><p>Help future comparisons understand this finding.</p><div className="verdicts">{['real','false positive','unsure'].map(x=><button className={verdict===x?'active':''} onClick={()=>setVerdict(x)} key={x}>{x}</button>)}</div></Card>
    </aside></div>{toast&&<div className="toast"><Icon name="check"/> Fix prompt copied with evidence</div>}
  </div>
}

function StateGraph() {
  return <div className="app-page graph-page"><AppPageHead title="State graph" copy="Run #024 · 14 of 21 discovered states visited" actions={<><Button variant="secondary">Filters</Button><Button variant="secondary">Fit view</Button></>}/>
    <div className="graph-legend"><span><i className="visited"/>Visited</span><span><i className="unreached"/>Unreached</span><span><i className="skipped"/>Skipped</span></div>
    <div className="graph-canvas"><svg className="edges" viewBox="0 0 1000 560" preserveAspectRatio="none"><path d="M130 280 C220 280 210 130 320 130M130 280 C220 280 220 420 330 420M390 130 C500 130 490 260 590 260M390 130 C520 130 520 60 670 60M400 420 C500 420 500 300 590 280M660 260 C760 260 760 150 850 150M660 280 C770 280 770 410 850 410"/></svg>
      {[['/','Home',10,44,'visited'],['/login','Login',30,18,'visited'],['/credits','Credits',31,70,'visited'],['/buy','Buy credits',59,43,'visited'],['external','Payment host',67,8,'skipped'],['/success','Success',85,24,'unreached'],['/history','History',85,70,'visited']].map(([r,n,x,y,s])=><div className={`graph-node ${s}`} style={{left:`${x}%`,top:`${y}%`}} key={n}><small>{r}</small><b>{n}</b><span>{s==='skipped'?'External host':s==='unreached'?'Blocked by prior error':'Visited'}</span></div>)}
    </div>
  </div>
}

function CompareRuns() {
  return <div className="app-page"><AppPageHead title="Compare runs" copy="#024 → #025 · Credit Kitchen" actions={<Button variant="secondary">Change runs</Button>}/><div className="compare-stats"><Metric label="Fixed" value="2"/><Metric label="New" value="1"/><Metric label="Still failing" value="3"/><Metric label="Intermittent" value="1"/></div>{[
    ['good','FIXED','Dead button: Save profile','Was reproducible by 2/5 agents'],
    ['critical','NEW','Coupon redemption accepted twice','Reproduced by 3/5 agents'],
    ['high','STILL FAILING','Double-submit creates duplicate credit rows','Reproduced in both runs'],
    ['medium','INTERMITTENT','Unhandled error with long display name','1/3 runs reproduced'],
  ].map(([tone,state,title,copy])=><Card className="diff-row" key={title}><Badge tone={tone as 'good'|'critical'|'high'|'medium'}>{state}</Badge><div><h3>{title}</h3><p>{copy}</p></div><Icon name="arrow"/></Card>)}</div>
}

function StaticScan() {
  return <div className="app-page"><AppPageHead title="Static scan" copy="27 rule hits across 14 files · sample data" actions={<Button variant="secondary">Export</Button>}/><div className="scan-layout"><aside className="scan-rules">{[['All rules','27'],['Unguarded mutation','8'],['Missing error state','6'],['Dead handler','4'],['External side effect','3'],['Other','6']].map(([x,n],i)=><button className={i===0?'active':''} key={x}><span>{x}</span><Badge tone="neutral">{n}</Badge></button>)}</aside><Card><div className="card-head"><h2>Rule hits</h2><label className="search-box"><Icon name="search"/><input aria-label="Filter files" placeholder="Filter files…"/></label></div>{[
    ['src/api/credits/buy.ts','48','Mutation follows a stale balance check without an idempotency key.','high'],
    ['src/components/ProfileForm.tsx','112','Submit control has no reachable click handler.','medium'],
    ['src/api/coupons/redeem.ts','67','Read-then-write may allow concurrent redemption.','critical'],
    ['src/routes/settings.tsx','21','Route action has no surfaced error state.','medium'],
  ].map(([f,line,d,t])=><div className="scan-hit" key={f}><Icon name="file"/><div><b>{f}:<mark>{line}</mark></b><p>{d}</p></div><Badge tone={t as 'high'|'medium'|'critical'}>{t.toUpperCase()}</Badge></div>)}</Card></div></div>
}

function Settings() {
  const tabs=['LLM mode','Safety','Team','Billing']
  return <div className="app-page settings-page"><AppPageHead title="Settings" copy="Project and workspace controls for Credit Kitchen."/><div className="settings-layout"><nav>{tabs.map((x,i)=><button className={i===0?'active':''} key={x}>{x}</button>)}</nav><div>
    <Card><h2>LLM mode</h2><p className="lede-small"><b>First line:</b> LLM mode is optional. When on, redacted summaries are sent to the provider you configure; code and secrets stay local.</p><Toggle label="Use LLM-assisted review" warning="Provider charges may apply." defaultOn/><label className="field"><span>Provider</span><select><option>Anthropic</option><option>OpenAI</option><option>None — local rules only</option></select></label><Field label="Key source" placeholder="ANTHROPIC_API_KEY"/><label className="field"><span>Model fallback order</span><textarea defaultValue={"claude-sonnet-[placeholder]\nclaude-haiku-[placeholder]"}/></label><Button>Save LLM settings</Button></Card>
    <Card><h2>Allowed hosts & ownership</h2><div className="host-row"><span><Icon name="check"/></span><div><b>localhost:3000</b><small>Verified · local machine</small></div><Button variant="ghost">Remove</Button></div><Button variant="secondary" icon="plus">Add host</Button></Card>
    <Card><h2>Database safety</h2><Toggle label="Require test database name" warning="Blocks runs unless the database includes “test”, “dev”, or “local”." defaultOn/><Toggle label="Allow database writes" warning="Required to test mutations. Use disposable data only." defaultOn/></Card>
    <Card><div className="card-head"><h2>Team & billing</h2><Badge tone="blue">COMING LATER</Badge></div><p>Team members, shared run history, and billing belong to the future hosted product. They are not available in the local beta.</p><Button disabled variant="secondary">Manage plan</Button></Card>
  </div></div></div>
}

function Onboarding() {
  const [step,setStep]=useState(1)
  return <div className="onboarding"><Logo/><div className="onboard-progress">{[1,2,3,4].map(x=><span className={x<=step?'active':''} key={x}>{x}</span>)}</div><Card className="onboard-card">
    <Eyebrow>STEP {step} OF 4</Eyebrow>
    {step===1&&<><h1>Connect a project</h1><p>Choose a local folder. Source files stay on this machine.</p><div className="drop-zone"><Icon name="file" size={34}/><b>Select project folder</b><small>or drag a folder here</small></div></>}
    {step===2&&<><h1>Confirm your stack</h1><p>We use this to select static rules and browser setup.</p><div className="stack-grid">{['React + Vite','Next.js','Vue / Nuxt','Other'].map((x,i)=><button className={i===0?'selected':''} key={x}><Icon name="code"/>{x}</button>)}</div></>}
    {step===3&&<><h1>Set a test target</h1><p>This must be a disposable, non-production copy.</p><Field label="Target URL" placeholder="http://localhost:3000"/><Callout tone="safe" title="Local target">This address resolves to your machine.</Callout></>}
    {step===4&&<><h1>Safety checklist</h1><p>Confirm both items before connecting this project.</p><label className="check-card"><input type="checkbox"/><span><b>This is a disposable test copy</b><small>I can restore its data if the test changes it.</small></span></label><label className="check-card"><input type="checkbox"/><span><b>Keep guarded actions skipped</b><small>Payments, deletes, and external effects remain off.</small></span></label></>}
    <div className="onboard-actions">{step>1&&<Button variant="secondary" onClick={()=>setStep(step-1)}>Back</Button>}<Button onClick={()=>step<4?setStep(step+1):navigate('/app/projects')} icon="arrow">{step===4?'Connect project':'Continue'}</Button></div>
  </Card></div>
}

function Auth({mode}:{mode:'signin'|'signup'|'forgot'}) {
  const titles={signin:'Welcome back',signup:'Create your preview account',forgot:'Reset your password'}
  return <div className="auth-page"><div className="auth-brand"><Logo/><div><Eyebrow>Future hosted preview</Eyebrow><h1>Break it here.<br/>Not in production.</h1><p>The hosted dashboard shown here is a concept. Join the beta for the local tool.</p></div><small>Code and secrets stay local.</small></div><div className="auth-form"><Card><h2>{titles[mode]}</h2><p>{mode==='forgot'?'We’ll send a reset link if the account exists.':mode==='signin'?'Sign in to the dashboard preview.':'Hosted access is not publicly available yet.'}</p>{mode==='signup'&&<Field label="Name" placeholder="Ada Lovelace"/>}<Field label="Email" type="email" placeholder="you@example.com"/>{mode!=='forgot'&&<Field label="Password" type="password" placeholder="At least 12 characters"/>}<Button>{mode==='signin'?'Sign in':mode==='signup'?'Create account':'Send reset link'}</Button>{mode==='signin'&&<a href="#/forgot">Forgot password?</a>}<div className="auth-switch">{mode==='signin'?'No account?': 'Already have an account?'} <a href={mode==='signin'?'#/signup':'#/signin'}>{mode==='signin'?'Join the beta':'Sign in'}</a></div></Card></div></div>
}

function BadgePage() {
  return <><PageHero eyebrow="Optional badge" title="Checked by UIpocalypse." copy="A small, honest badge for teams who want to share the scope of a specific run—not imply certification."/><section className="section page-width badge-showcase"><div className="checked-badge"><Logo compact/><span>CHECKED BY <b>UIpocalypse</b><small>LOCAL CHAOS RUN · [SAMPLE DATE]</small></span></div><Card><h2>What the badge means</h2><p>A configured local run completed against a test copy. The linked report should state exactly what ran, what was skipped, and which findings remained.</p><Callout tone="warn" title="Not a certification">The badge does not prove security, quality, accessibility, or the absence of bugs.</Callout><CodeBlock code={`<a href="[report-url]">\n  <img src="[badge-url]" alt="Checked by UIpocalypse" />\n</a>`}/></Card></section></>
}

function Sitemap() {
  const groups=[['Marketing',['Home','How it works','Features','Personas','Safety','Benchmarks','Pricing','Early access']],['Learn',['Docs hub','Quickstart','Safe test copy','MCP configuration','Blog','Changelog']],['Product preview',['Auth','Onboarding','Projects','New run','Live run','Report','Finding detail','State graph','Compare runs','Static scan','Settings']],['Company',['About','Contact','Terms','Privacy','404','Error page']]]
  return <><PageHero eyebrow="Navigation map" title="Everything has a place." copy="A reference for the marketing, learning, and future product surfaces in this prototype."/><section className="section page-width sitemap-grid">{groups.map(([g,items])=><Card key={g as string}><h2>{g}</h2>{(items as string[]).map(x=><span key={x}><Icon name="arrow"/>{x}</span>)}</Card>)}</section></>
}

function App() {
  const [path,setPath]=useState(route())
  const [theme,setTheme]=useState(()=>localStorage.getItem('ui-theme')||'dark')
  useEffect(()=>{const fn=()=>{setPath(route());window.scrollTo(0,0)};window.addEventListener('hashchange',fn);return()=>window.removeEventListener('hashchange',fn)},[])
  useEffect(()=>{document.documentElement.dataset.theme=theme;localStorage.setItem('ui-theme',theme)},[theme])

  const content=useMemo(()=>{
    if(path==='/') return <Landing/>
    if(path==='/how-it-works') return <HowItWorks/>
    if(path==='/features') return <FeaturesPage/>
    if(path==='/personas') return <Personas/>
    if(path==='/safety') return <Safety/>
    if(path==='/benchmarks') return <Benchmarks/>
    if(path==='/pricing') return <Pricing/>
    if(path==='/early-access') return <EarlyAccess/>
    if(path==='/docs'||path==='/docs/quickstart') return <Docs/>
    if(path.startsWith('/docs/')) { const raw=path.split('/').pop()||''; const found=docNav.find(x=>x.toLowerCase().replaceAll(' ','-')===raw); return <Docs article={found||'Quickstart'}/> }
    if(path==='/blog') return <Blog/>
    if(path==='/blog/article') return <BlogArticle/>
    if(path==='/about') return <About/>
    if(path==='/terms') return <Legal type="Terms"/>
    if(path==='/privacy') return <Legal type="Privacy"/>
    if(path==='/badge') return <BadgePage/>
    if(path==='/sitemap') return <Sitemap/>
    if(path==='/error') return <NotFound error/>
    return path==='/404'?<NotFound/>:null
  },[path])

  if(path==='/signin'||path==='/signup'||path==='/forgot') return <Auth mode={path.slice(1) as 'signin'|'signup'|'forgot'}/>
  if(path==='/app/onboarding') return <Onboarding/>
  if(path.startsWith('/app')||path==='/share/report') {
    const page=path==='/app/projects'?<Projects/>:path==='/app/project'?<ProjectOverview/>:path==='/app/new-run'?<NewRun/>:path==='/app/live-run'?<LiveRun/>:path==='/app/report'?<RunReport/>:path==='/app/finding'?<FindingDetail/>:path==='/app/graph'?<StateGraph/>:path==='/app/compare'?<CompareRuns/>:path==='/app/static-scan'?<StaticScan/>:path==='/app/settings'?<Settings/>:<Projects/>
    return path==='/share/report'?<RunReport shared/>:<AppShell theme={theme} setTheme={setTheme}>{page}</AppShell>
  }
  return <MarketingShell theme={theme} setTheme={setTheme}>{content||<NotFound/>}</MarketingShell>
}

export default App
